from django.apps import AppConfig


class NinosAppConfig(AppConfig):
    name = 'ninos_app'
